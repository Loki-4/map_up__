# Question 1: Reverse List by N Elements

def reverse_by_n_elements(lst, n):
    result = []
    for i in range(0, len(lst), n):
        group = lst[i:i+n]
        # Reverse manually
        reversed_group = []
        for j in range(len(group)):
            reversed_group.insert(0, group[j])
        result.extend(reversed_group)
    return result

lst = list(map(int, input("Enter the list of numbers (space-separated): ").split()))
n = int(input("Enter the value of n: "))
print("Reversed list in groups of n:", reverse_by_n_elements(lst, n))





# Question 2: Lists & Dictionaries

def group_by_length(lst):
    result = {}
    for word in lst:
        length = len(word)
        if length not in result:
            result[length] = []
        result[length].append(word)
    return dict(sorted(result.items()))
lst = input("Enter a list of words (space-separated): ").split()
print("Grouped by length:", group_by_length(lst))




# Question 3: Flatten a Nested Dictionary

def flatten_dict(d, parent_key='', sep='.'):
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            for i, item in enumerate(v):
                items.extend(flatten_dict(item, f"{new_key}[{i}]", sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


nested_dict = eval(input("Enter a nested dictionary: "))
print("Flattened dictionary:", flatten_dict(nested_dict))



# Question 4: Generate Unique Permutations

from itertools import permutations
def unique_permutations(lst):
    return sorted(set(permutations(lst)))
lst = list(map(int, input("Enter a list of integers (space-separated): ").split()))
print("Unique permutations:", unique_permutations(lst))






# Question 5: Find All Dates in a Text

import re
def find_all_dates(text):
    pattern = r'\b\d{2}-\d{2}-\d{4}|\b\d{2}/\d{2}/\d{4}|\b\d{4}\.\d{2}\.\d{2}'
    return re.findall(pattern, text)
text = input("Enter a text containing dates: ")
print("Valid dates found:", find_all_dates(text))







# Question 6: Decode Polyline, Convert to DataFrame with Distances

import polyline
import pandas as pd
from geopy.distance import geodesic

def polyline_to_df(polyline_str):
    # Check if the polyline string is empty
    if not polyline_str:
        print("The polyline string is empty.")
        return pd.DataFrame(columns=['latitude', 'longitude', 'distance'])
    
    try:
        coordinates = polyline.decode(polyline_str)
       
        if not coordinates:
            print("No coordinates found in the polyline.")
            return pd.DataFrame(columns=['latitude', 'longitude', 'distance'])
        
        data = {'latitude': [], 'longitude': [], 'distance': []}
        prev_point = None
        
        for lat, lon in coordinates:
            data['latitude'].append(lat)
            data['longitude'].append(lon)
            
            if prev_point is None:
                data['distance'].append(0)  # First point has 0 distance
            else:
                data['distance'].append(geodesic(prev_point, (lat, lon)).meters)
            
            prev_point = (lat, lon)
        

        return pd.DataFrame(data)
    
    except Exception as e:
        print(f"Error decoding polyline: {e}")
        return pd.DataFrame(columns=['latitude', 'longitude', 'distance'])


encoded_polyline = input("Enter the encoded polyline string: ")

df = polyline_to_df(encoded_polyline)

if not df.empty:
    print("Decoded Coordinates and Distances:")
    print(df)
else:
    print("No data to display.")





# Question 7: Matrix Rotation and Transformation

def rotate_and_transform(matrix):
    n = len(matrix)
    rotated_matrix = [[matrix[n-j-1][i] for j in range(n)] for i in range(n)]
    
    final_matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            row_sum = sum(rotated_matrix[i]) - rotated_matrix[i][j]
            col_sum = sum(rotated_matrix[k][j] for k in range(n)) - rotated_matrix[i][j]
            final_matrix[i][j] = row_sum + col_sum
    
    return final_matrix

n = int(input("Enter the size of the matrix (n x n): "))
matrix = []
for _ in range(n):
    row = list(map(int, input("Enter row elements (space-separated): ").split()))
    matrix.append(row)

print("Transformed matrix:", rotate_and_transform(matrix))





# Question 8: Time Check

import pandas as pd
from datetime import datetime

def load_data(file_path):
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception as e:
        print(f"Error loading the CSV file: {e}")
        return pd.DataFrame()

def check_time_completeness(df):
    # Ensure the DataFrame has the required columns
    required_columns = ['id', 'id_2', 'startDay', 'startTime', 'endDay', 'endTime']
    if not all(col in df.columns for col in required_columns):
        print("The CSV file does not contain the required columns.")
        return pd.Series(dtype=bool)

    # Convert startTime and endTime to datetime for easier processing
    df['startDatetime'] = df['startDay'] + ' ' + df['startTime']
    df['endDatetime'] = df['endDay'] + ' ' + df['endTime']
    
    df['startDatetime'] = pd.to_datetime(df['startDatetime'], errors='coerce')
    df['endDatetime'] = pd.to_datetime(df['endDatetime'], errors='coerce')
    
    # Create a boolean series to indicate if each (id, id_2) pair has incorrect timestamps
    complete_coverage = pd.Series(dtype=bool, index=pd.MultiIndex.from_frame(df[['id', 'id_2']].drop_duplicates()))
    
    for idx, group in df.groupby(['id', 'id_2']):
        # Check if the timestamps cover all 7 days of the week
        days_covered = group['startDay'].nunique() == 7
        # Check if there are 24 hours covered for each day
        hours_covered = all((group['endDatetime'] - group['startDatetime']).sum().total_seconds() >= 24 * 3600)
        
        # The pair is valid if both conditions are met
        complete_coverage[idx] = days_covered and hours_covered
    
    return complete_coverage

# User input for the CSV file path
file_path = input("Enter the file path for dataset-1.csv: ")

# Load the CSV data
df = load_data(file_path)

# Check for time completeness if the data was loaded successfully
if not df.empty:
    result = check_time_completeness(df)
    print("\nTime Completeness for each (id, id_2) pair:")
    print(result)
else:
    print("No data to process.")
